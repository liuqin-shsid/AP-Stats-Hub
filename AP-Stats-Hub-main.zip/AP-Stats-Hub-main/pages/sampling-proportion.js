/* Sampling Distribution for Proportions — 浏览器版
 * 对应原 Python 文件 sampling-distribution-for-proportions.py。
 * 布局：顶部控制栏（p 滑块 → n 滑块 2–40 → 模拟次数按钮组 → 清除样本 / 重置）
 *        + 一行提示 + 三张等宽等高图（每图下方为该图统计面板）。
 * 所有样式选择器都以 #proportionPage 作用域，避免影响其它页面。
 */
(() => {
  /* ---------- i18n ---------- */
  Object.assign(translations.zh, {
    proportion_title: '样本比例的抽样分布',
    proportion_desc: '改变总体比例 p 与样本量 n，观察单次样本与样本比例 p̂ 的累积抽样分布。',
    proportion_population: '(1) 总体分布',
    proportion_sample: '(2) 单次样本分布',
    proportion_sampling: '(3) 样本比例 p̂ 的累积抽样分布',
    proportion_pop_title: '总体 p = {p}（红 {success} / 蓝 {failure}）',
    proportion_population_p: '总体比例 p',
    proportion_sample_size: '样本量 n',
    proportion_simulations: '模拟次数',
    proportion_reset_samples: '清除样本',
    proportion_reset: '重置',
    proportion_count: '频数',
    proportion_sample_proportion: '样本比例 p̂',
    proportion_success: '成功 (1)',
    proportion_failure: '失败 (0)',
    proportion_pop_params: '总体参数',
    proportion_sample_stats: '样本统计量（最近一次）',
    proportion_sampling_stats: '样本比例 p̂ 的抽样分布',
    proportion_pop_p: '总体比例 p',
    proportion_sample_size_label: '样本量 n',
    proportion_batch_size: '批量大小',
    proportion_accum_total: '累计总数',
    proportion_mean_phat: 'p̂ 的均值',
    proportion_theory_mean: '理论 E[p̂]',
    proportion_std_phat: 'p̂ 的标准差',
    proportion_theory_se: '理论 SE',
    proportion_red_balls: '红球',
    proportion_blue_balls: '蓝球',
    proportion_no_sample: '暂无样本。',
    proportion_no_sampling: '暂无抽样。',
    proportion_click_sample: '点击上方按钮进行抽样。',
  });
  Object.assign(translations.en, {
    proportion_title: 'Sampling Distribution for Proportions',
    proportion_desc: 'Change the population proportion p and sample size n to compare a single sample with the accumulated sampling distribution of p̂.',
    proportion_population: '(1) Population Distribution',
    proportion_sample: '(2) Single-Sample Distribution',
    proportion_sampling: '(3) Sampling Distribution of p̂ (accumulated)',
    proportion_pop_title: 'Population p = {p} (red {success} / blue {failure})',
    proportion_population_p: 'Population p',
    proportion_sample_size: 'Sample size n',
    proportion_simulations: 'Number of simulations',
    proportion_reset_samples: 'Clear samples',
    proportion_reset: 'Reset',
    proportion_count: 'Frequency',
    proportion_sample_proportion: 'Sample proportion p̂',
    proportion_success: 'Success (1)',
    proportion_failure: 'Failure (0)',
    proportion_pop_params: 'Population Parameters',
    proportion_sample_stats: 'Sample Statistics (latest)',
    proportion_sampling_stats: 'Sampling Distribution of p̂',
    proportion_pop_p: 'Population p',
    proportion_sample_size_label: 'Sample size n',
    proportion_batch_size: 'Batch size',
    proportion_accum_total: 'Accumulated total',
    proportion_mean_phat: 'Mean of p̂',
    proportion_theory_mean: 'Theory E[p̂]',
    proportion_std_phat: 'Std of p̂',
    proportion_theory_se: 'Theory SE',
    proportion_red_balls: 'Red balls',
    proportion_blue_balls: 'Blue balls',
    proportion_no_sample: 'No sample yet.',
    proportion_no_sampling: 'No sampling yet.',
    proportion_click_sample: 'Click a sampling button above.',
  });

  /* ---------- 常量 ---------- */
  const TOTAL_BALLS = 1000;
  const BALL_COLS = 40;
  const SIM_OPTIONS = [1, 5, 10, 100, 500, 1000];
  const SVG_NS = 'http://www.w3.org/2000/svg';
  const COLORS = {
    success: '#cf493c',
    failure: '#2878b8',
    sampling: '#22a06b',
    p: '#c73932',
    mean: '#c17b23',
  };

  /* ---------- 状态 ---------- */
  const state = {
    p: 0.2,
    n: 20,
    batch: 5,
    accumulated: [],
    lastSample: null,
  };

  /* ---------- 工具函数 ---------- */
  const fmt = (v, d = 4) => (Number.isFinite(v) ? v.toFixed(d) : '—');
  const escapeHtml = (v) => String(v).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[c]));
  const binomial = (n, p) => { let s = 0; for (let i = 0; i < n; i++) if (Math.random() < p) s++; return s; };
  const mean = (a) => a.length ? a.reduce((x, y) => x + y, 0) / a.length : NaN;
  const variance = (a, ddof = 0) => {
    if (a.length <= ddof) return NaN;
    const m = mean(a);
    return a.reduce((s, v) => s + (v - m) ** 2, 0) / (a.length - ddof);
  };
  const sd = (a, ddof = 0) => Math.sqrt(variance(a, ddof));

  /* ---------- DOM 注入 ---------- */
  function buildUI() {
    const root = document.getElementById('proportionPage');
    root.innerHTML = `
      <div class="prop-page-heading">
        <h1 data-i18n="proportion_title"></h1>
        <p data-i18n="proportion_desc"></p>
      </div>
      <section class="prop-controls">
        <label class="prop-slider">
          <span data-i18n="proportion_population_p"></span>
          <input id="propP" type="range" min="0" max="1" step="0.01" value="0.20">
          <output id="propPValue">0.20</output>
        </label>
        <label class="prop-slider">
          <span data-i18n="proportion_sample_size"></span>
          <input id="propN" type="range" min="2" max="40" step="1" value="20">
          <output id="propNValue">20</output>
        </label>
        <div class="prop-sim-row">
          <span class="prop-sim-label" data-i18n="proportion_simulations"></span>
          <div class="prop-buttons">
            ${SIM_OPTIONS.map(v => `<button type="button" class="prop-sim-btn" data-batch="${v}">×${v}</button>`).join('')}
          </div>
        </div>
        <button id="propResetSamples" class="prop-reset-btn" type="button" data-i18n="proportion_reset_samples"></button>
        <button id="propResetAll" class="prop-reset-btn" type="button" data-i18n="proportion_reset"></button>
      </section>
      <p id="propHint" class="prop-hint" role="status"></p>
      <div class="prop-charts">
        <section class="prop-chart-card">
          <h2 data-i18n="proportion_population"></h2>
          <div class="prop-chart-wrap">
            <svg id="propPopChart" class="prop-chart" viewBox="0 0 460 340" preserveAspectRatio="xMidYMid meet" role="img"></svg>
          </div>
          <div id="propPopStats" class="prop-card-stats"></div>
        </section>
        <section class="prop-chart-card">
          <h2 data-i18n="proportion_sample"></h2>
          <div class="prop-chart-wrap">
            <svg id="propSampleChart" class="prop-chart" viewBox="0 0 460 340" preserveAspectRatio="xMidYMid meet" role="img"></svg>
          </div>
          <div id="propSampleStats" class="prop-card-stats"></div>
        </section>
        <section class="prop-chart-card">
          <h2 data-i18n="proportion_sampling"></h2>
          <div class="prop-chart-wrap">
            <svg id="propSamplingChart" class="prop-chart" viewBox="0 0 460 340" preserveAspectRatio="xMidYMid meet" role="img"></svg>
          </div>
          <div id="propSamplingStats" class="prop-card-stats"></div>
        </section>
      </div>
    `;
    document.getElementById('propP').addEventListener('input', e => {
      state.p = Number(e.target.value);
      document.getElementById('propPValue').textContent = state.p.toFixed(2);
      state.accumulated = []; state.lastSample = null; renderAll();
    });
    document.getElementById('propN').addEventListener('input', e => {
      state.n = Number(e.target.value);
      document.getElementById('propNValue').textContent = String(state.n);
      state.accumulated = []; state.lastSample = null; renderAll();
    });
    document.querySelectorAll('.prop-sim-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const k = Number(btn.dataset.batch);
        state.batch = k;
        let last = null;
        for (let i = 0; i < k; i++) {
          const s = binomial(state.n, state.p);
          state.accumulated.push(s / state.n);
          last = s;
        }
        state.lastSample = last;
        renderAll();
      });
    });
    document.getElementById('propResetSamples').addEventListener('click', () => {
      state.accumulated = []; state.lastSample = null; renderAll();
    });
    document.getElementById('propResetAll').addEventListener('click', () => {
      state.p = 0.20; state.n = 20; state.batch = 5;
      state.accumulated = []; state.lastSample = null;
      document.getElementById('propP').value = '0.20';
      document.getElementById('propPValue').textContent = '0.20';
      document.getElementById('propN').value = '20';
      document.getElementById('propNValue').textContent = '20';
      renderAll();
    });
  }

  /* ---------- 绘图原语 ---------- */
  function svgEl(tag, attrs = {}) {
    const el = document.createElementNS(SVG_NS, tag);
    for (const k in attrs) el.setAttribute(k, attrs[k]);
    return el;
  }
  function clearSvg(svg) { while (svg.firstChild) svg.removeChild(svg.firstChild); }
  function makeScale(domain, range) {
    return v => range[0] + (v - domain[0]) * (range[1] - range[0]) / (domain[1] - domain[0] || 1);
  }
  const SIZE = { w: 460, h: 340, m: { left: 56, right: 18, top: 18, bottom: 48 } };
  function drawAxes(svg, sz, xDomain, yDomain, opts = {}) {
    const { xlabel, ylabel, xTicks = 5, yTicks = 5 } = opts;
    const sx = makeScale(xDomain, [sz.m.left, sz.w - sz.m.right]);
    const sy = makeScale(yDomain, [sz.h - sz.m.bottom, sz.m.top]);
    for (let i = 0; i < xTicks; i++) {
      const v = xDomain[0] + (xDomain[1] - xDomain[0]) * i / (xTicks - 1);
      const x = sx(v);
      svg.appendChild(svgEl('line', { class: 'grid', x1: x, y1: sz.m.top, x2: x, y2: sz.h - sz.m.bottom }));
      const t = svgEl('text', { class: 'tick', x, y: sz.h - sz.m.bottom + 18, 'text-anchor': 'middle' });
      t.textContent = fmt(v, 1);
      svg.appendChild(t);
    }
    for (let i = 0; i < yTicks; i++) {
      const v = yDomain[0] + (yDomain[1] - yDomain[0]) * i / (yTicks - 1);
      const y = sy(v);
      svg.appendChild(svgEl('line', { class: 'grid', x1: sz.m.left, y1: y, x2: sz.w - sz.m.right, y2: y }));
      const t = svgEl('text', { class: 'tick', x: sz.m.left - 8, y: y + 4, 'text-anchor': 'end' });
      t.textContent = fmt(v, 1);
      svg.appendChild(t);
    }
    svg.appendChild(svgEl('path', {
      class: 'axis', fill: 'none',
      d: `M ${sz.m.left} ${sz.m.top} V ${sz.h - sz.m.bottom} H ${sz.w - sz.m.right}`,
    }));
    if (xlabel) {
      const t = svgEl('text', { class: 'axis-label', x: (sz.m.left + sz.w - sz.m.right) / 2, y: sz.h - 8, 'text-anchor': 'middle' });
      t.textContent = xlabel;
      svg.appendChild(t);
    }
    if (ylabel) {
      const t = svgEl('text', { class: 'axis-label', transform: `translate(14 ${(sz.m.top + sz.h - sz.m.bottom) / 2}) rotate(-90)`, 'text-anchor': 'middle' });
      t.textContent = ylabel;
      svg.appendChild(t);
    }
  }

  /* ---------- (1) 总体分布：彩色小球阵列 ---------- */
  function renderPopulation() {
    const svg = document.getElementById('propPopChart');
    clearSvg(svg);
    const success = Math.round(state.p * TOTAL_BALLS);
    const failure = TOTAL_BALLS - success;
    const colors = [];
    for (let i = 0; i < success; i++) colors.push('success');
    for (let i = 0; i < failure; i++) colors.push('failure');
    for (let i = colors.length - 1; i > 0; i--) {
      const j = (Math.random() * (i + 1)) | 0;
      [colors[i], colors[j]] = [colors[j], colors[i]];
    }
    const rows = Math.ceil(TOTAL_BALLS / BALL_COLS);
    const cols = BALL_COLS;
    const vbW = SIZE.w, vbH = SIZE.h;
    const padX = 8, padY = 22, padBottom = 8;
    const availW = vbW - padX * 2, availH = vbH - padY - padBottom;
    const cellW = availW / cols, cellH = availH / rows;
    for (let i = 0; i < colors.length; i++) {
      const r = (i / cols) | 0, c = i % cols;
      const cx = padX + (c + 0.5) * cellW;
      const cy = padY + (r + 0.5) * cellH;
      const rr = Math.min(cellW, cellH) * 0.44;
      svg.appendChild(svgEl('circle', {
        cx, cy, r: rr,
        fill: colors[i] === 'success' ? COLORS.success : COLORS.failure,
        stroke: '#000', 'stroke-width': 0.15,
      }));
    }
    const title = svgEl('text', {
      x: vbW / 2, y: 14, 'text-anchor': 'middle',
      fill: '#17324d', 'font-size': 12, 'font-weight': 700,
    });
    title.textContent = translations[lang].proportion_pop_title
      .replace('{p}', state.p.toFixed(2))
      .replace('{success}', String(success))
      .replace('{failure}', String(failure));
    svg.appendChild(title);

    const t = translations[lang];
    document.getElementById('propPopStats').innerHTML = `
      <div class="prop-card-stats-title">${escapeHtml(t.proportion_pop_params)}</div>
      <div class="prop-card-stats-line"><span>${escapeHtml(t.proportion_pop_p)}</span><b>${state.p.toFixed(4)}</b></div>
      <div class="prop-card-stats-line"><span>${escapeHtml(t.proportion_red_balls)}</span><b>${success}</b></div>
      <div class="prop-card-stats-line"><span>${escapeHtml(t.proportion_blue_balls)}</span><b>${failure}</b></div>
      <div class="prop-card-stats-line"><span>N</span><b>${TOTAL_BALLS.toLocaleString()}</b></div>
    `;
  }

  /* ---------- (2) 单次样本分布：柱状图 ---------- */
  function renderSample() {
    const svg = document.getElementById('propSampleChart');
    clearSvg(svg);
    const sz = SIZE;
    const n = state.n;
    const hasSample = state.lastSample !== null;
    const success = hasSample ? state.lastSample : 0;
    const failure = n - success;
    const counts = [success, failure];
    const labels = [translations[lang].proportion_success, translations[lang].proportion_failure];
    const maxC = Math.max(success, failure, 1);
    const yDomain = [0, maxC * 1.18];
    const xDomain = [0, 2];
    drawAxes(svg, sz, xDomain, yDomain, {
      xlabel: '', ylabel: translations[lang].proportion_count,
      xTicks: 3, yTicks: 5,
    });
    const sx = makeScale(xDomain, [sz.m.left, sz.w - sz.m.right]);
    const sy = makeScale(yDomain, [sz.h - sz.m.bottom, sz.m.top]);
    const barW = (sz.w - sz.m.left - sz.m.right) / 3;
    if (hasSample) {
      for (let i = 0; i < 2; i++) {
        const x = sx(i + 0.5) - barW / 2;
        const y = sy(counts[i]);
        const h = (sz.h - sz.m.bottom) - y;
        svg.appendChild(svgEl('rect', {
          x, y, width: barW, height: h,
          fill: i === 0 ? COLORS.success : COLORS.failure,
          stroke: '#000', 'stroke-width': 0.6, 'fill-opacity': 0.85,
        }));
        const t = svgEl('text', {
          x: sx(i + 0.5), y: y - 4, 'text-anchor': 'middle',
          fill: '#17324d', 'font-size': 12, 'font-weight': 700,
        });
        t.textContent = String(counts[i]);
        svg.appendChild(t);
      }
    }
    for (let i = 0; i < 2; i++) {
      const lb = svgEl('text', {
        x: sx(i + 0.5), y: sz.h - sz.m.bottom + 18, 'text-anchor': 'middle',
        fill: '#263844', 'font-size': 11,
      });
      lb.textContent = labels[i];
      svg.appendChild(lb);
    }
    const t = translations[lang];
    if (hasSample) {
      const phat = success / n;
      document.getElementById('propSampleStats').innerHTML = `
        <div class="prop-card-stats-title">${escapeHtml(t.proportion_sample_stats)}</div>
        <div class="prop-card-stats-line"><span>n</span><b>${n}</b></div>
        <div class="prop-card-stats-line"><span>p̂</span><b>${phat.toFixed(4)}</b></div>
      `;
    } else {
      document.getElementById('propSampleStats').innerHTML = `
        <div class="prop-card-stats-title">${escapeHtml(t.proportion_sample_stats)}</div>
        <div class="prop-card-stats-line muted">${escapeHtml(t.proportion_no_sample)}</div>
        <div class="prop-card-stats-line muted">${escapeHtml(t.proportion_click_sample)}</div>
      `;
    }
  }

  /* ---------- (3) 累积抽样分布 ---------- */
  function renderSampling() {
    const svg = document.getElementById('propSamplingChart');
    clearSvg(svg);
    const sz = SIZE;
    const data = state.accumulated;
    const xDomain = [0, 1];
    if (data.length === 0) {
      drawAxes(svg, sz, xDomain, [0, 1], {
        xlabel: translations[lang].proportion_sample_proportion,
        ylabel: translations[lang].proportion_count,
        xTicks: 6, yTicks: 5,
      });
    } else {
      // p̂ 是离散取值：0, 1/n, 2/n, …, 1
      const n = state.n;
      const bins = n + 1;
      const binW = 1 / n;
      const counts = new Array(bins).fill(0);
      for (const v of data) {
        let idx = Math.round(v * n);
        if (idx >= bins) idx = bins - 1;
        if (idx < 0) idx = 0;
        counts[idx]++;
      }
      const yMax = Math.max(...counts, 1) * 1.05;
      drawAxes(svg, sz, xDomain, [0, yMax], {
        xlabel: translations[lang].proportion_sample_proportion,
        ylabel: translations[lang].proportion_count,
        xTicks: 6, yTicks: 5,
      });
      const sx = makeScale(xDomain, [sz.m.left, sz.w - sz.m.right]);
      const sy = makeScale([0, yMax], [sz.h - sz.m.bottom, sz.m.top]);
      // 柱宽略小于取值间距，避免视觉上完全黏连；中心对准 k/n
      const fullW = sx(binW) - sx(0);
      const barW = fullW * 0.85;
      for (let i = 0; i < bins; i++) {
        if (!counts[i]) continue;
        const cx = sx(i * binW);
        const x = cx - barW / 2;
        const y = sy(counts[i]);
        const h = (sz.h - sz.m.bottom) - y;
        svg.appendChild(svgEl('rect', {
          x, y, width: barW, height: h,
          fill: COLORS.sampling, 'fill-opacity': 0.85,
        }));
      }
      svg.appendChild(svgEl('line', {
        x1: sx(state.p), x2: sx(state.p),
        y1: sz.m.top, y2: sz.h - sz.m.bottom,
        stroke: COLORS.p, 'stroke-width': 2, 'stroke-dasharray': '6 4',
      }));
      const m = mean(data);
      svg.appendChild(svgEl('line', {
        x1: sx(m), x2: sx(m),
        y1: sz.m.top, y2: sz.h - sz.m.bottom,
        stroke: COLORS.mean, 'stroke-width': 2, 'stroke-dasharray': '2 4',
      }));
    }
    const t = translations[lang];
    const total = data.length;
    const m = total ? mean(data) : NaN;
    const s = total > 1 ? sd(data, 1) : NaN;
    const se = Math.sqrt(state.p * (1 - state.p) / state.n);
    if (total === 0) {
      document.getElementById('propSamplingStats').innerHTML = `
        <div class="prop-card-stats-title">${escapeHtml(t.proportion_sampling_stats)}</div>
        <div class="prop-card-stats-line"><span>${escapeHtml(t.proportion_pop_p)}</span><b>${state.p.toFixed(4)}</b></div>
        <div class="prop-card-stats-line"><span>${escapeHtml(t.proportion_sample_size_label)}</span><b>${state.n}</b></div>
        <div class="prop-card-stats-line"><span>${escapeHtml(t.proportion_accum_total)}</span><b>0</b></div>
        <div class="prop-card-stats-line"><span>${escapeHtml(t.proportion_theory_mean)}</span><b>${state.p.toFixed(4)}</b></div>
        <div class="prop-card-stats-line"><span>${escapeHtml(t.proportion_theory_se)}</span><b>${fmt(se)}</b></div>
      `;
    } else {
      document.getElementById('propSamplingStats').innerHTML = `
        <div class="prop-card-stats-title">${escapeHtml(t.proportion_sampling_stats)}</div>
        <div class="prop-card-stats-line"><span>${escapeHtml(t.proportion_pop_p)}</span><b>${state.p.toFixed(4)}</b></div>
        <div class="prop-card-stats-line"><span>${escapeHtml(t.proportion_sample_size_label)}</span><b>${state.n}</b></div>
        <div class="prop-card-stats-line"><span>${escapeHtml(t.proportion_batch_size)}</span><b>${state.batch}</b></div>
        <div class="prop-card-stats-line"><span>${escapeHtml(t.proportion_accum_total)}</span><b>${total}</b></div>
        <div class="prop-card-stats-line"><span>${escapeHtml(t.proportion_mean_phat)}</span><b>${fmt(m)}</b></div>
        <div class="prop-card-stats-line"><span>${escapeHtml(t.proportion_theory_mean)}</span><b>${state.p.toFixed(4)}</b></div>
        <div class="prop-card-stats-line"><span>${escapeHtml(t.proportion_std_phat)}</span><b>${fmt(s)}</b></div>
        <div class="prop-card-stats-line"><span>${escapeHtml(t.proportion_theory_se)}</span><b>${fmt(se)}</b></div>
      `;
    }
  }

  /* ---------- 提示行 ---------- */
  function renderHint() {
    const el = document.getElementById('propHint');
    el.textContent = translations[lang].proportion_click_sample;
  }

  /* ---------- 统一渲染 ---------- */
  function renderAll() {
    renderPopulation();
    renderSample();
    renderSampling();
    renderHint();
  }

  /* ---------- 初始化 ---------- */
  function init() {
    buildUI();
    renderAll();
    // 页面显隐与标题交给 core/router.js，这里只负责切回本页时重绘。
    document.addEventListener('apstats:tool', e => { if (e.detail === 'proportion') renderAll(); });
    document.addEventListener('apstats:language', () => { renderAll(); });
  }

  init();
})();